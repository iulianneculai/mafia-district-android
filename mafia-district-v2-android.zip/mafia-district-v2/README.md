# Mafia District v2 — Multiplayer-Prototyp + Android-Projekt

Eigenständiges deutschsprachiges Mafia-Strategiespiel ohne Bilddateien. Die Oberfläche ist mit CSS gestaltet. Enthalten sind ein Node.js-Spielserver, Benutzerkonten, ein persistenter Spielwelt-Speicher, Multiplayer-Aktionen und eine für Android vorbereitete Capacitor-Web-App.

## Bereits enthalten
- Registrierung und Anmeldung (Passwörter mit Node.js scrypt gehasht; Sitzungs-Token)
- Servergespeicherter Spielstand und Ressourcen
- HQ-Upgrades, Tageskasse, Crew-Rekrutierung und XP/Level
- Gebäude: Hauptquartier, Garage, Waffenkammer, Versteck
- Helden, Waffen und Ausrüstung
- Weltkarte, Spielerliste und Angriffe mit Beute/Kampfberichten
- Allianzen gründen, beitreten und verlassen
- Weltchat und Allianzchat, Echtzeit-Updates via Socket.IO
- Responsive Oberfläche für Handy und Desktop
- Capacitor-Konfiguration für Android

## Lokal testen (Windows)
1. Node.js LTS installieren: https://nodejs.org/
2. ZIP entpacken.
3. Im Ordner `mafia-district-v2` in die Adresszeile des Datei-Explorers `cmd` eingeben und Enter drücken.
4. `npm install`
5. `npm start`
6. Im Browser `http://localhost:3000` öffnen.
7. Mit zwei unterschiedlichen Konten testen. Für den Test auf einem zweiten Gerät müssen beide Geräte denselben erreichbaren Server öffnen.

Die Welt wird in `data/world.json` gespeichert. Diese Datei und echte Spielerdaten nicht öffentlich teilen. Es ist ein Prototyp ohne E-Mail-Verifikation, Passwort-zurücksetzen, Rate-Limiting, Moderationswerkzeuge, Backups oder ausgereiftes Anti-Cheat.

## Android-App bauen
Eine Android-App braucht Android Studio, ein JDK (Android Studio enthält normalerweise eine passende JDK-Version), Android SDK und einen erreichbaren HTTPS-Server. Das Android-Paket kann nicht sinnvoll als alleinstehende Offline-App alle Multiplayer-Funktionen bereitstellen, weil Konten, Chat und Spielstände zentral auf dem Server liegen.

### 1. Spielserver hosten
- Stelle dieses Node.js-Projekt auf einem Node-fähigen Hosting mit dauerhaftem Speicher bereit.
- Setze `PORT` nach Vorgabe des Hosters.
- Verwende HTTPS und sichere Backups. Der Server schreibt Spielerdaten in `data/world.json`; bei flüchtigem Dateisystem brauchst du persistenten Speicher.
- Prüfe `/api/health`, um den Serverstatus zu testen.

### 2. Android-Projekt generieren
Im Projektordner ausführen:
```bash
npm install
```
Dann in `public/config.js` die URL deines HTTPS-Servers setzen:
```js
window.MAFIA_API_BASE = 'https://DEIN-SERVER.example';
```
Socket.IO verbindet sich ebenfalls zu dieser URL. Danach:
```bash
npx cap add android
npx cap sync android
npx cap open android
```
Android Studio öffnen lassen, Gradle synchronisieren und auf Emulator/Handy starten. Für eine APK: in Android Studio **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Für eine Veröffentlichung im Play Store sind zusätzlich Signierung, Datenschutzangaben, Test und Store-Metadaten erforderlich.

Wenn `npx cap add android` meldet, dass der Android-Ordner schon existiert, nicht erneut hinzufügen; `npx cap sync android` verwenden.

## Wichtige Grenzen
Dies ist eine Entwicklungsbasis, kein produktionsfertiges Live-Service-Spiel. Der JSON-Speicher ist für kleine Tests gedacht und nicht für viele gleichzeitige Nutzer; produktiv sollte PostgreSQL oder eine andere transaktionale Datenbank eingesetzt werden. Vor öffentlichem Betrieb müssen unter anderem Rate-Limits, sichere Token-Abläufe, Chat-Moderation/Melden/Blockieren, Angriffs-Cooldowns, Transaktionen, Server-Logs, Datenschutz/Impressum und Backup-/Restore-Verfahren ergänzt und getestet werden. Keine echten Zahlungen oder Echtgeldkäufe sind eingebaut.
