# Mafia District Android APK

This is an Android Studio/Gradle wrapper source project. It bundles the game interface in the APK. It is not a precompiled APK.

## Build with Android Studio
1. Install Android Studio and the Android SDK Platform 35.
2. Open the `android-wrapper` folder as a project.
3. In `app/build.gradle`, replace `https://YOUR-SERVER-URL` in `GAME_SERVER_URL` with the public HTTPS address where the Node.js game server is hosted.
4. Ensure `public/config.js` in the web client points at that same URL (`window.MAFIA_API_BASE = 'https://your-domain.example';`) and copy the updated public files into `app/src/main/assets/public/`.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Build APK via GitHub Actions
Push the project to a GitHub repository, then choose Actions > Build Mafia District APK > Run workflow. Download the `mafia-district-debug-apk` artifact after the workflow succeeds.

## Important
The UI is bundled, but accounts, shared multiplayer, alliances and chat need a public server. Do not use a debug APK as a Play Store release. A release needs a signed build, server-side security review, data protection/privacy notices and production database/backups.
