// Im Browser lokal leer lassen. Für die Android-App nach dem Hosting die HTTPS-URL eintragen:
// window.MAFIA_API_BASE = 'https://dein-spielserver.example';
window.MAFIA_API_BASE = '';
